package com.example.filedockultra

import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(36,48,36,36)}
        val title=TextView(this).apply{text="File Dock Ultra";textSize=30f;setPadding(0,0,0,10)}
        val sub=TextView(this).apply{text="A floating One UI-style file dock";textSize=16f;setPadding(0,0,0,25)}
        status=TextView(this).apply{textSize=16f;setPadding(0,0,0,18)}
        val permission=Button(this).apply{text="Allow display over other apps";setOnClickListener{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}}
        val start=Button(this).apply{text="Start File Dock";setOnClickListener{if(!Settings.canDrawOverlays(this@MainActivity))Toast.makeText(this@MainActivity,"Allow overlay permission first",Toast.LENGTH_LONG).show() else {ContextCompat.startForegroundService(this@MainActivity,Intent(this@MainActivity,DockService::class.java));Toast.makeText(this@MainActivity,"File Dock started",Toast.LENGTH_SHORT).show()}}}
        val stop=Button(this).apply{text="Stop File Dock";setOnClickListener{stopService(Intent(this@MainActivity,DockService::class.java))}}
        val pick=Button(this).apply{text="Add files";setOnClickListener{openPicker()}}
        box.addView(title);box.addView(sub);box.addView(status);box.addView(permission);box.addView(start);box.addView(stop);box.addView(pick)
        setContentView(box);updateStatus()
    }
    private fun openPicker(){startActivityForResult(Intent.createChooser(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)},"Choose files"),100)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=100||resultCode!=RESULT_OK||data==null)return;val list=ArrayList<Uri>();data.clipData?.let{for(i in 0 until it.itemCount)list.add(it.getItemAt(i).uri)} ?: data.data?.let{list.add(it)};if(list.isNotEmpty()){val s=Intent(this,DockService::class.java).apply{action="ADD";putParcelableArrayListExtra("uris",list)};ContextCompat.startForegroundService(this,s)}}
    override fun onResume(){super.onResume();updateStatus()}
    private fun updateStatus(){status.text=if(Settings.canDrawOverlays(this))"● Overlay permission: ON\nDock is ready" else "○ Overlay permission: OFF\nAllow it to use the floating dock"}
}
