package com.example.filedockultra

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import java.util.LinkedHashSet

class DockService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelShown = false
    private val items = LinkedHashSet<String>()
    private val prefs by lazy { getSharedPreferences("dock", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        loadItems()
        createChannel()
        startForeground(7, NotificationCompat.Builder(this, "dock")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .setContentTitle("File Dock Ultra")
            .setContentText("Floating dock is active")
            .setOngoing(true).build())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun windowParams(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 18)
            y = prefs.getInt("y", 420)
        }

    private fun rounded(bg: Int, radius: Float = 28f): GradientDrawable =
        GradientDrawable().apply { setColor(bg); cornerRadius = radius }

    private fun showBubble() {
        bubble = TextView(this).apply {
            text = "▣"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(35, 96, 210), 35f)
            setElevation(14f)
            setOnClickListener { togglePanel() }
            setOnDragListener { _, event -> handleDropEvent(event) }
            setOnTouchListener(DragTouchListener())
        }
        wm.addView(bubble, windowParams(70, 70))
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0; private var moved = false
        override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
            val p = v.layoutParams as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; moved=false; return true }
                MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt(); if(kotlin.math.abs(dx)>8||kotlin.math.abs(dy)>8)moved=true; p.x=startX+dx; p.y=startY+dy; wm.updateViewLayout(v,p); return true }
                MotionEvent.ACTION_UP -> { prefs.edit().putInt("x",p.x).putInt("y",p.y).apply(); if(!moved) v.performClick(); return true }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (panelShown) { closePanel(); return }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,18,18,14)
            background = rounded(Color.rgb(25,28,34), 30f)
            elevation = 20f
            setOnDragListener { _, event -> handleDropEvent(event) }
        }
        val header = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text="File Dock Ultra"; textSize=20f; setTextColor(Color.WHITE); layoutParams=LinearLayout.LayoutParams(0, -2,1f) }
        val close = Button(this).apply { text="×"; setTextColor(Color.WHITE); setOnClickListener{closePanel()} }
        header.addView(title); header.addView(close); panel!!.addView(header)
        val add = Button(this).apply { text="＋ Add files"; setOnClickListener{pickFiles()} }
        panel!!.addView(add)
        if(items.isEmpty()) panel!!.addView(TextView(this).apply{ text="No files yet. Add files to keep them one tap away."; setTextColor(Color.LTGRAY); setPadding(8,12,8,20) })
        items.toList().forEach { addFileRow(Uri.parse(it)) }
        wm.addView(panel, windowParams(360, WindowManager.LayoutParams.WRAP_CONTENT)); panelShown=true
    }

    private fun addFileRow(uri: Uri) {
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val name=TextView(this).apply{ text=fileName(uri); setTextColor(Color.WHITE); textSize=14f; setPadding(8,12,4,12); layoutParams=LinearLayout.LayoutParams(0,-2,1f) }
        val open=Button(this).apply{text="Open";setOnClickListener{openFile(uri)}}
        val share=Button(this).apply{text="Share";setOnClickListener{shareFile(uri)}}
        val del=Button(this).apply{text="×";setOnClickListener{removeFile(uri)}}
        row.addView(name);row.addView(open);row.addView(share);row.addView(del);panel?.addView(row)
    }

    /**
     * Accept files dragged from another Android app (Files, Gallery, browser,
     * email, etc.). The dropped ClipData URIs are added directly to the dock.
     */
    private fun handleDropEvent(event: DragEvent): Boolean {
        when (event.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                val desc = event.clipDescription
                return desc != null && (desc.hasMimeType("*/*") || desc.hasMimeType("text/uri-list") || desc.hasMimeType("text/plain"))
            }
            DragEvent.ACTION_DRAG_ENTERED -> {
                setDropHighlight(true)
                return true
            }
            DragEvent.ACTION_DRAG_EXITED -> {
                setDropHighlight(false)
                return true
            }
            DragEvent.ACTION_DROP -> {
                setDropHighlight(false)
                val clip = event.clipData ?: return false
                var added = 0
                for (i in 0 until clip.itemCount) {
                    val uri = clip.getItemAt(i).uri
                    if (uri != null) {
                        addUri(uri)
                        added++
                    }
                }
                if (added > 0 && panelShown) {
                    closePanel()
                    togglePanel()
                }
                return added > 0
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                setDropHighlight(false)
                return true
            }
        }
        return true
    }

    private fun setDropHighlight(active: Boolean) {
        val view: View = if (panelShown && panel != null) panel!! else (bubble ?: return)
        view.background = if (active) {
            rounded(Color.rgb(0, 150, 136), if (view === bubble) 35f else 30f)
        } else {
            rounded(if (view === bubble) Color.rgb(35, 96, 210) else Color.rgb(25,28,34), if (view === bubble) 35f else 30f)
        }
    }

    private fun pickFiles(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)}
        startActivity(i)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if(intent?.action=="ADD") intent.getParcelableArrayListExtra<Uri>("uris")?.forEach{addUri(it)}
        return START_STICKY
    }

    private fun addUri(uri:Uri){
        runCatching{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        if(items.add(uri.toString())) saveItems()
        if(panelShown){closePanel();togglePanel()}
    }
    private fun removeFile(uri:Uri){items.remove(uri.toString());saveItems();closePanel();togglePanel()}
    private fun openFile(uri:Uri){startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,contentResolver.getType(uri)?:"*/*");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)})}
    private fun shareFile(uri:Uri){startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=contentResolver.getType(uri)?:"*/*";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Share file").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}
    private fun fileName(uri:Uri):String{ var n:String?=null;runCatching{contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())n=it.getString(0)}};return n?:uri.lastPathSegment?:"File" }
    private fun saveItems(){val a=JSONArray();items.forEach{a.put(it)};prefs.edit().putString("items",a.toString()).apply()}
    private fun loadItems(){runCatching{val a=JSONArray(prefs.getString("items","[]"));for(i in 0 until a.length())items.add(a.getString(i))}}
    private fun closePanel(){panel?.let{runCatching{wm.removeView(it)}};panel=null;panelShown=false}
    override fun onDestroy(){bubble?.let{runCatching{wm.removeView(it)}};closePanel();super.onDestroy()}
    override fun onBind(intent:Intent?)=null
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("dock","File Dock",NotificationManager.IMPORTANCE_LOW))}
}
