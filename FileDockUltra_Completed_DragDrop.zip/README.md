# File Dock Ultra — completed project

A Samsung One UI-inspired floating file dock for Android 8+ / Android 15-16 compatible target configuration.

## Included
- Floating draggable dock bubble
- Persistent saved file URIs across service restarts
- Multi-file picker
- Open, Share and Remove actions
- Overlay permission flow
- Foreground service with Android 15/16 special-use declaration
- Position persistence for the floating bubble

## Build
Open this project in Android Studio, sync Gradle, then run `app` on the Galaxy S24 Ultra. The generated debug APK will be under `app/build/outputs/apk/debug/`.

## Drag & Drop
The floating dock now accepts Android drag-and-drop events. You can drag supported files/URIs from another app (such as a file manager, Gallery, browser or email app) onto the floating dock or open dock panel. Dropped URIs are added to the persistent dock list and the drop target highlights while dragging.
